//
//  SixthExperimentViewController.swift
//  App
//
//  Created by Pulkit Agarwal on 9/20/20.
//  Copyright © 2020 Pulkit Agarwal. All rights reserved.
//

import UIKit

class SixthExperimentViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        independantVariable.layer.borderWidth = 1.0
        trialOne.layer.borderWidth = 1.0
        trialTwo.layer.borderWidth = 1.0
        trialTHree.layer.borderWidth = 1.0


        // Do any additional setup after loading the view.
    }
        
    
    @IBOutlet weak var independantVariable: UILabel!
    @IBOutlet weak var trialOne: UILabel!
    @IBOutlet weak var trialTwo: UILabel!
    @IBOutlet weak var trialTHree: UILabel!
    }
