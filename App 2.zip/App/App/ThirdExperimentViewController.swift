//
//  ThirdExperimentViewController.swift
//  App
//
//  Created by Pulkit Agarwal on 9/20/20.
//  Copyright © 2020 Pulkit Agarwal. All rights reserved.
//

import UIKit

class ThirdExperimentViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    
    @IBOutlet weak var hypothesis: UITextView!
    
   
    @IBAction func transferData(_ sender: Any) {
        Variables.hypothesis = hypothesis.text
    }
    
}
