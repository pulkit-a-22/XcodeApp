//
//  GraphViewController.swift
//  App
//
//  Created by Pulkit Agarwal on 9/27/20.
//  Copyright © 2020 Pulkit Agarwal. All rights reserved.
//

import UIKit

class GraphViewController: UIViewController {

  

    @IBOutlet weak var chartView: MacawChartView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        chartView.contentMode = .scaleAspectFit
        MacawChartView.playAnimations()
    }
    

}
