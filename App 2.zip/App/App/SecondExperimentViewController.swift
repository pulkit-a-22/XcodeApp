//
//  SecondExperimentViewController.swift
//  App
//
//  Created by Pulkit Agarwal on 9/20/20.
//  Copyright © 2020 Pulkit Agarwal. All rights reserved.
//

import UIKit

class SecondExperimentViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    
    @IBOutlet weak var research: UITextView!
    
    
    @IBAction func transferData(_ sender: Any) {
        Variables.research = research.text
    }
    
}
