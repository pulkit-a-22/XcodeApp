//
//  NinthExperimentViewController.swift
//  App
//
//  Created by Pulkit Agarwal on 9/20/20.
//  Copyright © 2020 Pulkit Agarwal. All rights reserved.
//

import UIKit
import SimplePDF


class NinthExperimentViewController: UIViewController {
    
    /// Creating UIDocumentInteractionController instance.
    let documentInteractionController = UIDocumentInteractionController()
    
        
    override func viewDidLoad() {
        super.viewDidLoad()
        documentInteractionController.delegate = self

        
        let A4paperSize = CGSize(width: 595, height: 842)
        let pdf = SimplePDF(pageSize: A4paperSize, pageMargin: 20.0)
        _ = SimplePDF(pageSize: A4paperSize, pageMarginLeft: 35, pageMarginTop: 50, pageMarginBottom: 40, pageMarginRight: 35)
        
        
        pdf.addText( "some text" )
        pdf.addLineSeparator(height: 30) // or pdf.addLineSeparator() default height is 1.0
        pdf.addLineSpace(20)
      
        if let documentDirectories = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first {
            
            let fileName = "example.pdf"
            let documentsFileName = documentDirectories + "/" + fileName
            
            let pdfData = pdf.generatePDFdata()
            do{
                try pdfData.write(to: URL(fileURLWithPath: "/Users/pulkit.agarwal/Desktop/App/hello"), options: .atomic)
            }catch{
                print(error)
            }
        }
        
}
    
    @IBAction func showOptions(_ sender: Any) {
        storeAndShare(fileURLWithPath: "/Users/pulkit.agarwal/Desktop/App/hello")

    }
    
    override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
        }
    }

    extension NinthExperimentViewController {
        /// This function will set all the required properties, and then provide a preview for the document
        func share(url: URL) {
            documentInteractionController.url = url
            documentInteractionController.uti = url.typeIdentifier ?? "public.data, public.content"
            documentInteractionController.name = url.localizedName ?? url.lastPathComponent
            documentInteractionController.presentPreview(animated: true)
        }
        
        /// This function will store your document to some temporary URL and then provide sharing, copying, printing, saving options to the user
        func storeAndShare(fileURLWithPath: String) {
            guard let url = URL(string: fileURLWithPath) else { return }
            print(url)
            /// START YOUR ACTIVITY INDICATOR HERE
            URLSession.shared.dataTask(with: url) { data, response, error in
                guard let data = data, error == nil else { return }
                let tmpURL = FileManager.default.temporaryDirectory
                    .appendingPathComponent(response?.suggestedFilename ?? "fileName.png")
                do {
                    try data.write(to: tmpURL)
                } catch {
                    print(error)
                }
                DispatchQueue.main.async {
                    /// STOP YOUR ACTIVITY INDICATOR HERE
                    self.share(url: tmpURL)
                }
                }.resume()
        }
    }

    extension NinthExperimentViewController: UIDocumentInteractionControllerDelegate {
        /// If presenting atop a navigation stack, provide the navigation controller in order to animate in a manner consistent with the rest of the platform
        func documentInteractionControllerViewControllerForPreview(_ controller: UIDocumentInteractionController) -> UIViewController {
            guard let navVC = self.navigationController else {
                return self
            }
            return navVC
        }
    }

    extension URL {
        var typeIdentifier: String? {
            return (try? resourceValues(forKeys: [.typeIdentifierKey]))?.typeIdentifier
        }
        var localizedName: String? {
            return (try? resourceValues(forKeys: [.localizedNameKey]))?.localizedName
        }
    
        
        
        
    
 

}
