//
//  FourthExperimentViewController.swift
//  App
//
//  Created by Pulkit Agarwal on 9/20/20.
//  Copyright © 2020 Pulkit Agarwal. All rights reserved.
//

import UIKit

class FourthExperimentViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBOutlet weak var independant: UITextView!
    @IBOutlet weak var independantUnits: UITextView!
    @IBOutlet weak var dependant: UITextView!
    @IBOutlet weak var dependantUnits: UITextView!
    @IBOutlet weak var trials: UITextField!
    
    
    @IBAction func transferData(_ sender: Any) {
        Variables.independant = independant.text
        Variables.independantUnits = independantUnits.text
        Variables.dependant = dependant.text
        Variables.dependantUnits = dependantUnits.text
        
        
    }
    
}
