//
//  SeventhExperimentViewController.swift
//  App
//
//  Created by Pulkit Agarwal on 9/20/20.
//  Copyright © 2020 Pulkit Agarwal. All rights reserved.
//

import UIKit

class SeventhExperimentViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var opinion: UITextView!
    @IBOutlet weak var conclusion: UITextView!
    
    
    
    @IBAction func transferData(_ sender: Any) {
        Variables.opinion = opinion.text
        Variables.conclusion = conclusion.text
    }
    
}
