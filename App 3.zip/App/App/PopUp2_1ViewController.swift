//
//  PopUp2_1ViewController.swift
//  App
//
//  Created by Pulkit Agarwal on 9/20/20.
//  Copyright © 2020 Pulkit Agarwal. All rights reserved.
//

import UIKit

class PopUp2_1ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func closePopUp2_1(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
}
