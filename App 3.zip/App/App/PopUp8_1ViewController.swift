//
//  PopUp8_1ViewController.swift
//  App
//
//  Created by Pulkit Agarwal on 9/20/20.
//  Copyright © 2020 Pulkit Agarwal. All rights reserved.
//

import UIKit

class PopUp8_1ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
    @IBAction func close8PopUp1(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    
    

}
