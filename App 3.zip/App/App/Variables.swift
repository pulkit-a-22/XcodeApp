//
//  globalVariables.swift
//  App
//
//  Created by Pulkit Agarwal on 9/26/20.
//  Copyright © 2020 Pulkit Agarwal. All rights reserved.
//

import Foundation
import UIKit

class Variables: UIViewController {

    static var observation = String()
    static var question = String()
    static var research = String()
    static var hypothesis = String()
    static var independant = String()
    static var independantUnits = String()
    static var dependant = String()
    static var dependantUnits = String()
    static var Units = String()
    static var control = String()
    static var procedure = String()
    static var opinion = String()
    static var conclusion = String()
    static var revised = String()
    static var error = String()
    
    
    static var iv1 = String()
    static var iv2 = String()
    static var iv3 = String()
    static var iv4 = String()
    static var iv5 = String()
    
    
    static var trial1 = String()
   
    

}
    
