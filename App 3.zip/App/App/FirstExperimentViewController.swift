//
//  FirstExperimentViewController.swift
//  App
//
//  Created by Pulkit Agarwal on 9/20/20.
//  Copyright © 2020 Pulkit Agarwal. All rights reserved.
//

import UIKit

class FirstExperimentViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBOutlet weak var observationText: UITextView!
    @IBOutlet weak var question: UITextView!
    
    
    @IBAction func transferData(_ sender: Any) {
        Variables.observation = observationText.text
        Variables.question = question.text
    }
    
    
    
    
}
