//
//  FifthExperimentViewController.swift
//  App
//
//  Created by Pulkit Agarwal on 9/20/20.
//  Copyright © 2020 Pulkit Agarwal. All rights reserved.
//

import UIKit

class FifthExperimentViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBOutlet weak var control: UITextView!
    @IBOutlet weak var procedure: UITextView!
    
    
    @IBAction func transferData(_ sender: Any) {
        Variables.control = control.text
        Variables.procedure = procedure.text
    }
    
    
}
