//
//  testViewController.swift
//  App
//
//  Created by Pulkit Agarwal on 9/28/20.
//  Copyright © 2020 Pulkit Agarwal. All rights reserved.
//

import UIKit
import SimplePDF

class testViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
  let A4paperSize = CGSize(width: 595, height: 842)
           let pdf = SimplePDF(pageSize: A4paperSize, pageMargin: 20.0)
           _ = SimplePDF(pageSize: A4paperSize, pageMarginLeft: 35, pageMarginTop: 50, pageMarginBottom: 40, pageMarginRight: 35)
           
           
    if; let documentDirectories = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first {_ in
        
        let fileName = "example.pdf"
        let documentsFileName = documentDirectories + "/" + fileName
        
        let pdfData = pdf.generatePDFdata()
        do{
            try pdfData.writeToFile(documentsFileName, options: .DataWritingAtomic)
            print("\nThe generated pdf can be found at:")
            print("\n\t\(documentsFileName)\n")
        }catch{
            print(error)
        }
    }
    
}
