//
//  File.swift
//  App
//
//  Created by Pulkit Agarwal on 9/27/20.
//  Copyright © 2020 Pulkit Agarwal. All rights reserved.
//

import Foundation

struct BarGraph {
    var showNumber: String
    var dependant: Double
}
