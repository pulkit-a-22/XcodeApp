//
//  NinthExperimentViewController.swift
//  App
//
//  Created by Pulkit Agarwal on 9/20/20.
//  Copyright © 2020 Pulkit Agarwal. All rights reserved.
//

import UIKit
import SimplePDF


class NinthExperimentViewController: UIViewController {
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let A4paperSize = CGSize(width: 595, height: 842)
        let pdf = SimplePDF(pageSize: A4paperSize, pageMargin: 20.0)
        _ = SimplePDF(pageSize: A4paperSize, pageMarginLeft: 35, pageMarginTop: 50, pageMarginBottom: 40, pageMarginRight: 35)
        
        
        pdf.addText( "some text" )
        pdf.addLineSeparator(height: 30) // or pdf.addLineSeparator() default height is 1.0
        pdf.addLineSpace(20)
      
        if let documentDirectories = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first {
            
            let fileName = "example.pdf"
            let documentsFileName = documentDirectories + "/" + fileName
            
            let pdfData = pdf.generatePDFdata()
            do{
                try pdfData.writeToFile(documentsFileName, options: .DataWritingAtomic)
                print("\nThe generated pdf can be found at:")
                print("\n\t\(documentsFileName)\n")
            }catch{
                print(error)
            }
        }

}
 

}
